## SVP Corporates — Serviced Apartments, Nagpur

A single-scroll editorial landing page inspired by the reference PDF, but with sharper typography and more restrained composition. All sections live on `/` with smooth anchor scroll.

### Visual direction

- **Palette** (grey / beige / black, refined)
  - Bone `#F4F0EA` (background)
  - Warm sand `#E4DCCE` (secondary surfaces)
  - Graphite `#1C1B18` (foreground)
  - Muted taupe `#8A8378` (muted text / hairlines)
  - Deep espresso `#2A2621` (accent CTA)
- **Typography** — editorial pairing, better than the reference's uniform sans:
  - Display: **Fraunces** (high-contrast serif, tight tracking, huge weights for the "BESPOKE / CORPORATE STAYS" moments)
  - Body / labels: **Inter Tight** with wide letter-spacing on all-caps eyebrows
  - Micro-labels in uppercase 11px, tracking 0.18em (like the reference's "MAX 2 GUESTS" tags but more disciplined)
- **Composition**: generous whitespace, hairline dividers, asymmetric two-column blocks, oversized section numerals ("01 — STAY", "02 — AMENITIES"), full-bleed imagery with tight captions.
- **Motion**: subtle fade/slide-in on scroll, image parallax on hero, hover lift on cards. Nothing loud.

### Page structure (single scroll)

1. **Sticky slim nav** — SVP wordmark left, anchor links (Stay · Amenities · About · Offers · Contact) right, "Reserve" button.
2. **Hero** — full-viewport image of a Nagpur apartment interior, oversized serif headline "Corporate stays, quietly refined.", eyebrow "SVP CORPORATES · NAGPUR", primary CTA "Book your stay", secondary "Explore apartments".
3. **Intro / What sets us apart** — two-column: large serif statement left, two short paragraphs right about long-stay comfort for business travelers in Nagpur.
4. **Apartments grid** (replaces "Rooms & Suites") — 6 cards: Studio, Executive Studio, One-Bedroom, Deluxe One-Bedroom, Two-Bedroom, Penthouse Suite. Each: image, micro-label (guests/beds), name, "From ₹X,XXX/night →".
5. **Amenities** — 3-up with images: 24/7 Concierge, Rooftop Lounge, In-house Restaurant (plus a 4th row: Business Center, Housekeeping, Airport Transfer as icon list).
6. **Awards / Recognition** — 5 award blurbs in a clean typographic grid.
7. **Featured apartment showcase** — editorial layout with 3 detail photos + floor-plan-style block, captions in serif italic.
8. **Testimonials** — 3-column pull quotes with attribution.
9. **Special offers / Packages** — 6-card grid: Extended Stay, Corporate Retreat, Weekend Escape, Wellness Package, Airport & Stay, Business Trip Special.
10. **Contact / Footer** — address (Nagpur), phone, email placeholders, business hours, social links, brand lockup.

### Technical

- Add route content in `src/routes/index.tsx` (single page, sectioned components in `src/components/svp/`).
- Update `src/routes/__root.tsx` head: title "SVP Corporates — Serviced Apartments in Nagpur", meta description, og tags.
- Load Fraunces + Inter Tight via `@fontsource` (`bun add @fontsource/fraunces @fontsource-variable/inter-tight`), import in `src/router.tsx` or a client entry, wire family names as `--font-display` / `--font-sans` in `src/styles.css` `@theme`.
- Update `src/styles.css` `:root` tokens to the palette above (oklch), keep dark theme neutral.
- Generate ~10 hero/apartment/amenity/offer images with `imagegen` (warm interiors, Nagpur/Indian architectural cues where sensible), save under `src/assets/`, import as ES modules.
- Smooth-scroll anchor navigation, `scroll-margin-top` on sections for the sticky nav.
- Fully responsive (mobile: single column, hero text scales down, nav collapses to logo + Reserve button).

### Out of scope

- No booking backend, no CMS, no auth — content is static placeholder copy tailored to SVP Corporates Nagpur.
- No multi-page routing; everything lives on `/`.
